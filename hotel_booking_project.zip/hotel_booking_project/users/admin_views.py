from django.contrib.auth.models import User
from bookings.models import Booking
from rest_framework import viewsets, permissions
from rest_framework.response import Response
from rest_framework import serializers


class UserStatsSerializer(serializers.ModelSerializer):
    total_bookings = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'total_bookings']

    def get_total_bookings(self, obj):
        request = self.context.get('request')
        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if start_date and end_date:
            return Booking.objects.filter(
                user=obj,
                check_in__date__range=[start_date, end_date]
            ).count()
        return Booking.objects.filter(user=obj).count()


class AdminUserStatsViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = UserStatsSerializer
    permission_classes = [permissions.IsAdminUser]

    def get_queryset(self):
        return User.objects.all()
