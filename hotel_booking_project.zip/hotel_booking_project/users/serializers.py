from django.contrib.auth.models import User
from rest_framework import serializers
from .models import Profile
from bookings.models import Booking



class UserSignupSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        user = User.objects.create_user(**validated_data)
        return user



class ProfileSerializer(serializers.ModelSerializer):
    user = serializers.StringRelatedField(read_only=True)
    booking_count = serializers.SerializerMethodField()
    id = serializers.IntegerField(read_only=True)
    photo = serializers.ImageField(use_url=True, allow_null=True, required=False)

    class Meta:
        model = Profile
        fields = ['id','user', 'address', 'gender', 'photo', 'booking_count']

    def get_booking_count(self, obj):
        request = self.context.get('request', None)
        if not request:
            return 0

        start_date = request.query_params.get('start_date')
        end_date = request.query_params.get('end_date')

        if start_date and end_date:
            return Booking.objects.filter(
                user=obj.user,
                check_in__date__range=[start_date, end_date]
            ).count()
        return Booking.objects.filter(user=obj.user).count()
