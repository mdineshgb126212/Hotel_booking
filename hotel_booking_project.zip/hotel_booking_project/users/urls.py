from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import SignupViewSet, ProfileViewSet
from .admin_views import AdminUserStatsViewSet

router = DefaultRouter()
router.register(r'register', SignupViewSet, basename='register')
router.register(r'profile', ProfileViewSet, basename='profile')
router.register(r'admin/users', AdminUserStatsViewSet, basename='admin-user-stats')

urlpatterns = router.urls
