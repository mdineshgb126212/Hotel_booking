from django.db import models

class Hotel(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    description = models.TextField(blank=True)
    city = models.CharField(max_length=100, default="Hyderabad")
    price_per_night = models.DecimalField(max_digits=10, decimal_places=2, default=1000)
    available_rooms = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.name
