from rest_framework import viewsets, permissions, status
from .models import Booking
from .serializers import BookingSerializer
from rest_framework.response import Response
from django.utils.dateparse import parse_date
from datetime import datetime
from rest_framework.exceptions import ValidationError

class BookingViewSet(viewsets.ModelViewSet):
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        booking_id = self.request.query_params.get('booking_id')
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')


        if user.is_staff:
            queryset = Booking.objects.all()
        else:
            queryset = Booking.objects.filter(user=user)


        if booking_id:
            queryset = queryset.filter(id=booking_id)


        if start_date and end_date:
            try:
                start = datetime.strptime(start_date, "%Y-%m-%d").date()
                end = datetime.strptime(end_date, "%Y-%m-%d").date()
                queryset = queryset.filter(check_in__date__range=(start, end))
            except ValueError:
                raise ValidationError("Date format must be YYYY-MM-DD")

        return queryset

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
